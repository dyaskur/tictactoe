Tic-tac-toe is a paper-and-pencil game for two players, X and O, who take turns marking the spaces in a 3×3 grid.

but I modified this game so you can scale the grid up to 9x9 grid.

best regard

Dyas Yaskur
